function validateForm() {
  let username = document.getElementById("username");
  let password = document.getElementById("password");
  let valid = true;

  document.getElementById("usernameError").innerText = "";
  document.getElementById("passwordError").innerText = "";

  if (username.value.trim() === "") {
    document.getElementById("usernameError").innerText = "Username is required";
    valid = false;
  }

  if (password.value.trim() === "") {
    document.getElementById("passwordError").innerText = "Password is required";
    valid = false;
  }

  return valid;
}

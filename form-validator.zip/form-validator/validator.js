// Validation rules config
const validationRules = {
  email: {
    required: true,
    pattern: /^[^\s@]+@[^\s@]+\.[^\s@]+$/,
    message: "Please enter a valid email address",
  },
  password: {
    required: true,
    minLength: 8,
    pattern: /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).+$/,
    message:
      "Password must be at least 8 characters and include upper, lower, number and symbol",
  },
  phone: {
    required: true,
    pattern: /^[0-9]{10,13}$/,
    message: "Phone number must be 10-13 digits",
  },
};

function validateField(name, value) {
  const rules = validationRules[name];
  if (!rules) return "";

  if (rules.required && !value.trim()) {
    return "This field is required";
  }

  if (rules.minLength && value.length < rules.minLength) {
    return `Minimum length is ${rules.minLength}`;
  }

  if (rules.pattern && !rules.pattern.test(value)) {
    return rules.message;
  }

  return "";
}

function validateForm(form) {
  let isValid = true;
  const inputs = form.querySelectorAll("input");

  inputs.forEach((input) => {
    const errorDiv = input.nextElementSibling;
    const errorMsg = validateField(input.name, input.value);
    errorDiv.textContent = errorMsg;

    if (errorMsg) isValid = false;
  });

  return isValid;
}

// Attach event listener
document
  .getElementById("registrationForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    if (validateForm(this)) {
      alert("Form submitted successfully!");
      this.reset();
    }
  });
